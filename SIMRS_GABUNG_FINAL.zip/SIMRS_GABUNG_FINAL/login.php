<?php
session_start();
if (isset($_SESSION['user'])) { header('Location: portal.php'); exit; }

$accounts = [
 'admin'         => ['password'=>'admin123',   'name'=>'Administrator',               'role'=>'admin',               'role_label'=>'Administrator'],
 'petugas'       => ['password'=>'petugas123', 'name'=>'Andi Putra',                  'role'=>'petugas_registrasi',  'role_label'=>'Petugas Registrasi'],
 'radiolog'      => ['password'=>'radiolog123','name'=>'dr. Andi Pratama',             'role'=>'radiologist',         'role_label'=>'Dokter Radiologi'],
 'dokter'        => ['password'=>'dokter123',  'name'=>'dr. Ahmad Fauzi, Sp.PD',       'role'=>'dokter',              'role_label'=>'Dokter'],
 'perawat'       => ['password'=>'perawat123', 'name'=>'Ns. Rina Wulandari, S.Kep',   'role'=>'perawat',             'role_label'=>'Perawat / Bidan'],
 'kasir'         => ['password'=>'kasir123',   'name'=>'Dewi Rahayu, S.E.',            'role'=>'kasir',               'role_label'=>'Kasir / Billing'],
 'farmasi'       => ['password'=>'farmasi123', 'name'=>'A. Putri',                     'role'=>'farmasi',             'role_label'=>'Farmasi / Apoteker'],
 'laboran'       => ['password'=>'laboran123', 'name'=>'A. Laboran',                   'role'=>'laboratorium',        'role_label'=>'Laboratorium'],
 'gudang'        => ['password'=>'gudang123',  'name'=>'Petugas Gudang',               'role'=>'gudang',              'role_label'=>'Petugas Gudang'],
 'kepala_gudang' => ['password'=>'head123',    'name'=>'Kepala Gudang',                'role'=>'kepala_gudang',       'role_label'=>'Kepala Gudang'],
 'executive'     => ['password'=>'exec123',    'name'=>'Management Executive',         'role'=>'executive',           'role_label'=>'Management Executive'],
 'analyst'       => ['password'=>'analyst123', 'name'=>'Data Analyst',                 'role'=>'analyst',             'role_label'=>'Data Analyst'],
];

$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $username=trim($_POST['username']??'');
 $password=$_POST['password']??'';
 if(isset($accounts[$username]) && hash_equals($accounts[$username]['password'],$password)) {
   $_SESSION['user']=['username'=>$username]+$accounts[$username];
   header('Location: portal.php');
   exit;
 }
 $error='Username atau password salah.';
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - RS Suka Sehat</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="login-page">
<div class="decor decor-1">+</div><div class="decor decor-2">+</div><div class="login-wave"></div>
<main class="login-container login-container-wide">
  <div class="brand"><img src="assets/logo.png"><div><div class="brand-name">RS <span>Suka</span> Sehat</div><div class="brand-subtitle">Sistem Informasi Manajemen Rumah Sakit</div></div></div>
  <section class="login-card">
    <h1>Masuk ke Akun Anda</h1>
    <?php if($error): ?><div class="error-box">⚠ <?=htmlspecialchars($error)?></div><?php endif; ?>
    <form method="post">
      <label>Username</label>
      <div class="input-wrap"><span>♙</span><input name="username" required autofocus placeholder="Masukkan username"></div>
      <label>Password</label>
      <div class="input-wrap"><span>🔒</span><input id="password" name="password" type="password" required placeholder="Masukkan password"><button type="button" class="eye" onclick="password.type=password.type==='password'?'text':'password'">◉</button></div>
      <button class="login-button" type="submit">Login</button>
    </form>

    <div class="demo-box">
      <h3>12 Akun Demo</h3>
      <div class="demo-grid">
        <div class="demo-account"><strong>1. Administrator</strong><span>admin / <b>admin123</b></span></div>
        <div class="demo-account"><strong>2. Petugas Registrasi</strong><span>petugas / <b>petugas123</b></span></div>
        <div class="demo-account"><strong>3. Dokter Radiologi</strong><span>radiolog / <b>radiolog123</b></span></div>
        <div class="demo-account"><strong>4. Dokter</strong><span>dokter / <b>dokter123</b></span></div>
        <div class="demo-account"><strong>5. Perawat / Bidan</strong><span>perawat / <b>perawat123</b></span></div>
        <div class="demo-account"><strong>6. Kasir / Billing</strong><span>kasir / <b>kasir123</b></span></div>
        <div class="demo-account"><strong>7. Farmasi / Apoteker</strong><span>farmasi / <b>farmasi123</b></span></div>
        <div class="demo-account"><strong>8. Laboratorium</strong><span>laboran / <b>laboran123</b></span></div>
        <div class="demo-account"><strong>9. Petugas Gudang</strong><span>gudang / <b>gudang123</b></span></div>
        <div class="demo-account"><strong>10. Kepala Gudang</strong><span>kepala_gudang / <b>head123</b></span></div>
        <div class="demo-account"><strong>11. Management Executive</strong><span>executive / <b>exec123</b></span></div>
        <div class="demo-account"><strong>12. Data Analyst</strong><span>analyst / <b>analyst123</b></span></div>
      </div>
    </div>
  </section>
  <footer>RS Suka Sehat • SIMRS Terintegrasi</footer>
</main>
</body>
</html>
