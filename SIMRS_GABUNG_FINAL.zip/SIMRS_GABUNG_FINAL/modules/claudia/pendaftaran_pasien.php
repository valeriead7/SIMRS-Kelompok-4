<?php
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user = $_SESSION['user'];

$userName = $user['name']
    ?? $user['full_name']
    ?? 'Andi Putra';

$userRole = 'Petugas Registrasi';
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Pendaftaran Pasien Baru - RS Suka Sehat</title>

    <style>

        /* =====================================================
           RESET
        ===================================================== */

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #eef8fa;
            color: #07506d;
        }

        button,
        input,
        select,
        textarea {
            font-family: inherit;
        }


        /* =====================================================
           LAYOUT
        ===================================================== */

        .app {
            display: flex;
            min-height: 100vh;
        }


        /* =====================================================
           SIDEBAR
        ===================================================== */

        .sidebar {
            width: 212px;
            min-width: 212px;
            background: #07566f;
            color: white;
            min-height: 100vh;
            padding: 16px 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 4px 6px 25px;
        }

        .brand-logo {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            object-fit: cover;
            background: white;
            flex-shrink: 0;
        }

        .brand-text strong {
            display: block;
            font-size: 15px;
            line-height: 18px;
        }

        .brand-text strong span {
            color: #f26b9b;
        }

        .brand-text small {
            display: block;
            margin-top: 3px;
            font-size: 9px;
            color: #d8edf2;
        }


        /* SIDEBAR MENU */

        .menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 10px;

            min-height: 38px;

            padding: 9px 12px;

            border-radius: 8px;

            color: white;
            text-decoration: none;

            font-size: 12px;
            font-weight: 600;
        }

        .menu a:hover {
            background: rgba(255,255,255,.10);
        }

        .menu a.active {
            background: #087f80;
        }

        .menu-icon {
            width: 18px;
            text-align: center;
            font-size: 14px;
        }


        /* =====================================================
           MAIN
        ===================================================== */

        .main {
            flex: 1;
            min-width: 0;
            padding: 10px 22px 40px;
        }


        /* =====================================================
           TOPBAR
        ===================================================== */

        .topbar {
            height: 52px;

            background: white;

            border: 1px solid #d7e9ee;
            border-radius: 10px;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 14px;

            margin-bottom: 18px;
        }

        .search {
            display: flex;
            align-items: center;
            gap: 9px;

            color: #668898;
            font-size: 12px;
        }

        .search-icon {
            font-size: 15px;
        }

        .top-user {
            display: flex;
            align-items: center;
            gap: 9px;
            height: 42px;
            white-space: nowrap;
        }

        .user-icon {
            width: 30px;
            height: 30px;

            border-radius: 50%;

            background: #07566f;
            color: white;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 13px;
        }

        .user-name {
            display: flex;
            flex-direction: column;
            justify-content: center;
            line-height: 1.1;
        }

        .user-name strong {
            color: #07506d;
            font-size: 12px;
        }

        .user-name small {
            color: #7896a2;
            font-size: 8px;
            margin-top: 2px;
        }

        .logout {
            color: #07506d;
            text-decoration: none;
            font-size: 11px;
            font-weight: 700;
            margin-left: 7px;
        }


        /* =====================================================
           BREADCRUMB
        ===================================================== */

        .breadcrumb {
            font-size: 10px;
            color: #658b9a;
            margin: 4px 0 8px;
        }

        .breadcrumb span {
            margin: 0 5px;
        }


        /* =====================================================
           PAGE HEADER
        ===================================================== */

        .page-header {
            position: relative;
            min-height: 75px;
            margin-bottom: 2px;
            overflow: hidden;
        }

        .page-header h1 {
            margin: 0;
            font-size: 26px;
            color: #07506d;
            line-height: 32px;
        }

        .page-header p {
            margin: 5px 0 0;
            color: #6d8e9b;
            font-size: 12px;
        }

        .page-decoration {
            position: absolute;
            right: 15px;
            top: -20px;

            font-size: 80px;

            opacity: .12;
        }


        /* =====================================================
           FORM CARD
        ===================================================== */

        .form-card {
            background: white;

            border: 1px solid #d7e8ed;

            border-radius: 10px;

            padding: 12px 14px;

            margin-bottom: 10px;
        }


        /* =====================================================
           SECTION TITLE
        ===================================================== */

        .section-title {
            height: 39px;

            display: flex;
            align-items: center;

            gap: 10px;

            background: linear-gradient(
                90deg,
                #e4f6f3,
                #eefaf8
            );

            border-radius: 8px;

            padding: 0 10px;

            margin-bottom: 12px;
        }

        .section-icon {
            width: 30px;
            height: 30px;

            border-radius: 50%;

            display: flex;
            align-items: center;
            justify-content: center;

            background: #238f7d;

            color: white;

            font-size: 15px;
        }

        .section-title strong {
            font-size: 14px;
            color: #07506d;
        }


        /* =====================================================
           GRID
        ===================================================== */

        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .grid-full {
            width: 100%;
        }


        /* =====================================================
           FORM GROUP
        ===================================================== */

        .form-group {
            margin-bottom: 12px;
        }

        .form-label {
            display: block;

            margin-bottom: 5px;

            font-size: 10px;
            font-weight: 700;

            color: #07506d;
        }

        .required {
            color: #ef6d70;
        }


        /* =====================================================
           INPUT
        ===================================================== */

        .input-box {
            position: relative;
        }

        .input-box .input-icon {
            position: absolute;

            left: 10px;
            top: 50%;

            transform: translateY(-50%);

            font-size: 13px;

            color: #638da0;

            pointer-events: none;
        }

        input[type="text"],
        input[type="date"],
        input[type="tel"],
        select,
        textarea {

            width: 100%;

            border: 1px solid #d4e4e9;

            border-radius: 6px;

            background: white;

            color: #476f80;

            font-size: 11px;

            outline: none;
        }

        input[type="text"],
        input[type="date"],
        input[type="tel"],
        select {

            height: 34px;

            padding: 0 10px;
        }

        .with-icon {
            padding-left: 35px !important;
        }

        textarea {
            min-height: 78px;
            padding: 10px;
            resize: vertical;
        }

        input::placeholder,
        textarea::placeholder {
            color: #91aab5;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #48a7a0;

            box-shadow:
                0 0 0 2px rgba(72,167,160,.10);
        }


        /* =====================================================
           RADIO
        ===================================================== */

        .radio-group {
            display: flex;
            align-items: center;
            gap: 20px;

            height: 34px;
        }

        .radio-option {
            display: flex;
            align-items: center;
            gap: 5px;

            color: #315f70;

            font-size: 11px;
        }

        .radio-option input {
            accent-color: #278d7c;
            width: 15px;
            height: 15px;
        }


        /* =====================================================
           DIVIDER
        ===================================================== */

        .divider {
            border: 0;
            border-top: 1px solid #e2edf0;

            margin: 6px 0 14px;
        }


        /* =====================================================
           FOOTER BUTTON
        ===================================================== */

        .form-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;

            margin-top: 12px;
        }

        .btn {
            height: 36px;

            border-radius: 6px;

            padding: 0 28px;

            border: 1px solid #cfe1e6;

            background: white;

            color: #315f70;

            font-size: 11px;
            font-weight: 700;

            cursor: pointer;
        }

        .btn:hover {
            background: #f4fafb;
        }

        .btn-save {
            border: none;

            background: #087f80;

            color: white;

            min-width: 112px;
        }

        .btn-save:hover {
            background: #076f70;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 900px) {

            .sidebar {
                width: 180px;
                min-width: 180px;
            }

            .grid-2 {
                grid-template-columns: 1fr;
                gap: 0;
            }

        }

        @media (max-width: 650px) {

            .sidebar {
                display: none;
            }

            .main {
                padding: 8px 10px 30px;
            }

            .topbar {
                padding: 0 10px;
            }

            .user-name {
                display: none;
            }

            .page-header h1 {
                font-size: 22px;
            }

        }

    </style>

</head>


<body>

<div class="app">


    <!-- =====================================================
         SIDEBAR
         ===================================================== -->

    <aside class="sidebar">

        <div class="brand">

            <img
                src="assets/logo.png"
                class="brand-logo"
                alt="RS Suka Sehat"
            >

            <div class="brand-text">

                <strong>
                    RS <span>Suka</span> Sehat
                </strong>

                <small>
                    SIMRS
                </small>

            </div>

        </div>


        <nav class="menu">

            <a href="dashboard.php">

                <span class="menu-icon">🏠︎</span>

                Dashboard

            </a>


            <a href="pendaftaran_pasien.php"
               class="active">

                <span class="menu-icon">♟+</span>

                Pendaftaran Pasien

            </a>


            <a href="registrasi_pasien.php">

                <span class="menu-icon">✍</span>

                Registrasi Kunjungan

            </a>


            <a href="data_pasien.php">

                <span class="menu-icon">📋</span>

                Data Pasien

            </a>

        </nav>

    </aside>


    <!-- =====================================================
         MAIN
         ===================================================== -->

    <main class="main">


        <!-- TOPBAR -->

        <header class="topbar">

            <div class="search">

                <span class="search-icon">🔎</span>

                <span>
                    Cari menu...
                </span>

            </div>


            <div class="top-user">

                <div class="user-icon">
                    👤
                </div>

                <div class="user-name">

                    <strong>
                        <?= htmlspecialchars($userName) ?>
                    </strong>

                    <small>
                        <?= htmlspecialchars($userRole) ?>
                    </small>

                </div>

                <a
                    href="logout.php"
                    class="logout"
                >
                    Logout
                </a>

            </div>

        </header>


        <!-- =====================================================
             BREADCRUMB
             ===================================================== -->

        <div class="breadcrumb">

            🏠

            <span>›</span>

            Pendaftaran Pasien

            <span>›</span>

            Pasien Baru

        </div>


        <!-- =====================================================
             PAGE HEADER
             ===================================================== -->

        <div class="page-header">

            <h1>
                Pendaftaran Pasien Baru
            </h1>

            <p>
                Lengkapi data pasien untuk proses pendaftaran
            </p>

            <div class="page-decoration">
                📋
            </div>

        </div>


        <!-- =====================================================
             FORM
             ===================================================== -->

        <form
            method="POST"
            action=""
            autocomplete="off"
        >


            <!-- =================================================
                 DATA IDENTITAS PASIEN
                 ================================================= -->

            <div class="form-card">

                <div class="section-title">

                    <div class="section-icon">
                        👤
                    </div>

                    <strong>
                        Data Identitas Pasien
                    </strong>

                </div>


                <div class="grid-2">


                    <!-- NAMA -->

                    <div class="form-group">

                        <label class="form-label">

                            Nama Lengkap
                            <span class="required">*</span>

                        </label>

                        <div class="input-box">

                            <span class="input-icon">
                                ♙
                            </span>

                            <input
                                type="text"
                                name="nama"
                                class="with-icon"
                                placeholder="Contoh: Budi Santoso"
                            >

                        </div>

                    </div>


                    <!-- NIK -->

                    <div class="form-group">

                        <label class="form-label">

                            NIK (KTP)
                            <span class="required">*</span>

                        </label>

                        <div class="input-box">

                            <span class="input-icon">
                                ▣
                            </span>

                            <input
                                type="text"
                                name="nik"
                                class="with-icon"
                                maxlength="16"
                                placeholder="16 digit angka"
                            >

                        </div>

                    </div>


                    <!-- TANGGAL LAHIR -->

                    <div class="form-group">

                        <label class="form-label">

                            Tanggal lahir
                            <span class="required">*</span>

                        </label>

                        <div class="input-box">

                            <span class="input-icon">
                                ▣
                            </span>

                            <input
                                type="date"
                                name="tanggal_lahir"
                                class="with-icon"
                            >

                        </div>

                    </div>


                    <!-- JENIS KELAMIN -->

                    <div class="form-group">

                        <label class="form-label">

                            Jenis Kelamin
                            <span class="required">*</span>

                        </label>

                        <div class="radio-group">

                            <label class="radio-option">

                                <input
                                    type="radio"
                                    name="jenis_kelamin"
                                    value="Laki-laki"
                                >

                                Laki-laki

                            </label>


                            <label class="radio-option">

                                <input
                                    type="radio"
                                    name="jenis_kelamin"
                                    value="Perempuan"
                                >

                                Perempuan

                            </label>

                        </div>

                    </div>


                    <!-- GOLONGAN DARAH -->

                    <div class="form-group">

                        <label class="form-label">
                            Golongan Darah
                        </label>

                        <select name="golongan_darah">

                            <option value="">
                                Tidak diketahui
                            </option>

                            <option value="A">
                                A
                            </option>

                            <option value="B">
                                B
                            </option>

                            <option value="AB">
                                AB
                            </option>

                            <option value="O">
                                O
                            </option>

                        </select>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 ALAMAT & KONTAK
                 ================================================= -->

            <div class="form-card">

                <div class="section-title">

                    <div class="section-icon">
                        🏠
                    </div>

                    <strong>
                        Alamat & Kontak
                    </strong>

                </div>


                <!-- ALAMAT -->

                <div class="form-group">

                    <label class="form-label">

                        Alamat Lengkap

                    </label>

                    <div class="input-box">

                        <span class="input-icon">
                            📍
                        </span>

                        <textarea
                            name="alamat"
                            class="with-icon"
                            placeholder="Jl. Nama Jalan, RT/RW, Kelurahan, Kecamatan"
                        ></textarea>

                    </div>

                </div>


                <div class="divider"></div>


                <!-- NOMOR HP -->

                <div class="form-group">

                    <label class="form-label">

                        Nomor HP
                        <span class="required">*</span>

                    </label>

                    <div class="input-box">

                        <span class="input-icon">
                            ☎
                        </span>

                        <input
                            type="tel"
                            name="no_hp"
                            class="with-icon"
                            placeholder="08xxxxxxxxxx"
                        >

                    </div>

                </div>

            </div>


            <!-- =================================================
                 KUNJUNGAN INI
                 ================================================= -->

            <div class="form-card">

                <div class="section-title">

                    <div class="section-icon">
                        🏥
                    </div>

                    <strong>
                        Kunjungan Ini
                    </strong>

                </div>


                <div class="grid-2">


                    <!-- POLIKLINIK -->

                    <div class="form-group">

                        <label class="form-label">

                            Tujuan Poliklinik
                            <span class="required">*</span>

                        </label>

                        <select name="poliklinik">

                            <option value="">
                                -- Pilih Poliklinik --
                            </option>

                            <option value="Poliklinik Umum">
                                Poliklinik Umum
                            </option>

                            <option value="Poliklinik Anak">
                                Poliklinik Anak
                            </option>

                            <option value="Poliklinik Penyakit Dalam">
                                Poliklinik Penyakit Dalam
                            </option>

                            <option value="Poliklinik Bedah">
                                Poliklinik Bedah
                            </option>

                            <option value="Poliklinik Kandungan">
                                Poliklinik Kandungan
                            </option>

                        </select>

                    </div>


                    <!-- PENJAMIN -->

                    <div class="form-group">

                        <label class="form-label">

                            Jenis Penjaminan
                            <span class="required">*</span>

                        </label>

                        <div class="radio-group">

                            <label class="radio-option">

                                <input
                                    type="radio"
                                    name="penjamin"
                                    value="Umum"
                                >

                                Umum

                            </label>


                            <label class="radio-option">

                                <input
                                    type="radio"
                                    name="penjamin"
                                    value="BPJS"
                                >

                                BPJS

                            </label>


                            <label class="radio-option">

                                <input
                                    type="radio"
                                    name="penjamin"
                                    value="Asuransi Swasta"
                                >

                                Asuransi Swasta

                            </label>

                        </div>

                    </div>

                </div>


                <!-- BUTTON -->

                <div class="form-actions">

                    <button
                        type="reset"
                        class="btn"
                    >
                        ✕&nbsp; Batal
                    </button>


                    <button
                        type="submit"
                        class="btn btn-save"
                    >
                        ▣&nbsp; Simpan
                    </button>

                </div>

            </div>


        </form>


    </main>

</div>

</body>
</html>