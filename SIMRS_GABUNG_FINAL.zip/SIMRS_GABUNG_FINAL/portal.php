<?php
session_start();
if(!isset($_SESSION['user'])){ header('Location: login.php'); exit; }
$u=$_SESSION['user'];

$roles = [
 'admin'=>['title'=>'Administrasi Sistem','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['akun','Kelola Akun Pengguna','👤','modules/claudia/kelola_akun.php'],
   ['akses','Hak Akses','🔐','modules/claudia/hak_akses.php'],
   ['audit','Log Aktivitas','◉','modules/claudia/log_aktivitas.php'],
   ['pengaturan','Pengaturan','⚙','modules/claudia/pengaturan_admin.php'],
 ]],
 'petugas_registrasi'=>['title'=>'Registrasi','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['registrasi','Registrasi Pasien','👤','modules/claudia/pendaftaran_pasien.php'],
   ['pasien','Data Pasien','▤','modules/claudia/data_pasien.php'],
   ['appointment','Scheduling & Appointment','🗓','modules/max/index.html?sso=1&role=scheduling','appointment-list'],
   ['jadwal','Jadwal Dokter','◷','modules/max/index.html?sso=1&role=scheduling','doctor-schedule'],
 ]],
 'radiologist'=>['title'=>'Radiologi','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['order','Order Radiologi','☢','modules/claudia/order_pasien_radiolog.php'],
   ['hasil','Daftar Hasil Radiologi','▤','modules/claudia/daftar_hasil_radiolog.php'],
 ]],
 'dokter'=>['title'=>'Dokter','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['emr','Electronic Medical Record','📋','modules/valerie/simrs%20gabung%203%20modul.html?sso=1&role=dokter','switchModule("emr")'],
   ['cpoe','CPOE / Order','▣','modules/valerie/simrs%20gabung%203%20modul.html?sso=1&role=dokter','switchModule("cpoe","order")'],
   ['status','Pantau Status Order','↻','modules/valerie/simrs%20gabung%203%20modul.html?sso=1&role=dokter','switchModule("cpoe","status")'],
   ['cancel','Batalkan Order','↪','modules/valerie/simrs%20gabung%203%20modul.html?sso=1&role=dokter','switchModule("cpoe","cancel")'],
 ]],
 'perawat'=>['title'=>'Perawat / Bidan','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['emr','Electronic Medical Record','📋','modules/valerie/simrs%20gabung%203%20modul.html?sso=1&role=perawat','switchModule("emr")'],
   ['nursing','Nursing','🩹','modules/valerie/simrs%20gabung%203%20modul.html?sso=1&role=perawat','switchModule("nursing")'],
 ]],
 'kasir'=>['title'=>'Kasir / Billing','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['rekap','Rekapitulasi Biaya','▤','modules/sharon/kasir_sso.html?sso=1&role=kasir','show("rekap")'],
   ['riwayat','Riwayat Transaksi','◷','modules/sharon/kasir_sso.html?sso=1&role=kasir','show("riwayat")'],
   ['invoice','Cetak Invoice','🖨','modules/sharon/kasir_sso.html?sso=1&role=kasir','show("invoice")'],
 ]],
 'farmasi'=>['title'=>'Farmasi','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['resep','Daftar Resep','▤','modules/max/index.html?sso=1&role=pharmacy','go("pharmacy-prescriptions")'],
   ['dispensing','Dispensing Resep','✚','modules/max/index.html?sso=1&role=pharmacy','go("pharmacy-dispensing")'],
   ['stok','Stok Obat','▣','modules/max/index.html?sso=1&role=pharmacy','go("pharmacy-stock")'],
   ['retur','Retur Obat','↩','modules/max/index.html?sso=1&role=pharmacy','go("pharmacy-return")'],
   ['laporan','Laporan','📊','modules/max/index.html?sso=1&role=pharmacy','go("pharmacy-report")'],
 ]],
 'laboratorium'=>['title'=>'Laboratorium','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['orderlab','Order Laboratorium','⚗','modules/max/index.html?sso=1&role=laboratory','go("lab-orders")'],
   ['verifikasi','Verifikasi Spesimen','✓','modules/max/index.html?sso=1&role=laboratory','go("lab-verify")'],
   ['input','Input Hasil','▣','modules/max/index.html?sso=1&role=laboratory','go("lab-input")'],
   ['validasi','Validasi Hasil','✓','modules/max/index.html?sso=1&role=laboratory','go("lab-validate")'],
   ['hasil','Hasil Laboratorium','▥','modules/max/index.html?sso=1&role=laboratory','go("lab-final")'],
 ]],
 'gudang'=>['title'=>'Gudang / Inventory','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['inventory','Inventory','📦','modules/mikael/index.html?sso=1&role=inventory_officer','showPage("inventory")'],
   ['receiving','Penerimaan Barang','🚚','modules/mikael/index.html?sso=1&role=inventory_officer','showPage("receiving")'],
   ['mutation','Mutasi Barang','🔄','modules/mikael/index.html?sso=1&role=inventory_officer','showPage("mutation")'],
   ['stockopname','Stock Opname','📋','modules/mikael/index.html?sso=1&role=inventory_officer','showPage("stockopname")'],
 ]],
 'kepala_gudang'=>['title'=>'Kepala Gudang','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['inventory','Inventory','📦','modules/mikael/index.html?sso=1&role=inventory_head','showPage("inventory")'],
   ['receiving','Penerimaan Barang','🚚','modules/mikael/index.html?sso=1&role=inventory_head','showPage("receiving")'],
   ['mutation','Mutasi Barang','🔄','modules/mikael/index.html?sso=1&role=inventory_head','showPage("mutation")'],
   ['stockopname','Stock Opname','📋','modules/mikael/index.html?sso=1&role=inventory_head','showPage("stockopname")'],
   ['approval','Approval Stok Opname','✓','modules/mikael/index.html?sso=1&role=inventory_head','showPage("approval")'],
   ['audit','Audit Log','◉','modules/mikael/index.html?sso=1&role=inventory_head','showPage("audit")'],
 ]],
 'executive'=>['title'=>'Management Executive','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['executive','Executive Dashboard','📈','modules/mikael/index.html?sso=1&role=management_executive','showPage("executive")'],
 ]],
 'analyst'=>['title'=>'Data Analyst','menus'=>[
   ['dashboard','Dashboard','⌂',''],
   ['reports','Laporan Khusus / Rekap','📑','modules/mikael/index.html?sso=1&role=data_analyst','showPage("reports")'],
   ['audit','Audit Log','◉','modules/mikael/index.html?sso=1&role=data_analyst','showPage("audit")'],
 ]],
];

if(!isset($roles[$u['role']])){ session_destroy(); header('Location: login.php'); exit; }
$cfg=$roles[$u['role']]; $menus=$cfg['menus'];
$page=$_GET['page']??'dashboard'; $current=$menus[0];
foreach($menus as $m){ if($m[0]===$page){$current=$m;break;} }
$isDashboard=$current[0]==='dashboard';

$stats = [
 'admin'=>[['Pengguna Aktif','112'],['Role Tersedia','12'],['Login Hari Ini','1.245'],['Aktivitas Audit','542']],
 'petugas_registrasi'=>[['Pasien Hari Ini','86'],['Registrasi Baru','24'],['Appointment','31'],['Menunggu','7']],
 'radiologist'=>[['Order Masuk','18'],['Menunggu Baca','6'],['Selesai','11'],['Prioritas','1']],
 'dokter'=>[['Pasien Hari Ini','18'],['EMR Aktif','18'],['Order Aktif','9'],['Selesai','12']],
 'perawat'=>[['Pasien Dirawat','24'],['Assessment','18'],['Obat Terjadwal','31'],['Dokumentasi','20']],
 'kasir'=>[['Transaksi','46'],['Menunggu Bayar','3'],['Invoice','41'],['Lunas','39']],
 'farmasi'=>[['Resep Baru','32'],['Dalam Proses','18'],['Selesai','46'],['Ditolak','3']],
 'laboratorium'=>[['Order Hari Ini','28'],['Verifikasi','6'],['Dalam Proses','14'],['Selesai','8']],
 'gudang'=>[['Total Item','1.284'],['Total Stok','8.542'],['Mendekati Expiry','24'],['Mutasi','8']],
 'kepala_gudang'=>[['Total Item','1.284'],['Approval','1'],['Mutasi','8'],['Audit Hari Ini','14']],
 'executive'=>[['BOR','78,4%'],['LOS','4,2 hari'],['TOI','1,3 hari'],['Pendapatan','Rp 8,42 M']],
 'analyst'=>[['Laporan Aktif','12'],['Ekspor Hari Ini','7'],['Dataset','18'],['Audit','542']],
];
$s=$stats[$u['role']];
?>
<!doctype html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=htmlspecialchars($cfg['title'])?> - SIMRS</title><link rel="stylesheet" href="assets/style.css">
<style>
body{background:#f3f8fa}.main-content{margin-left:235px;min-height:100vh;padding:0;background:#f3f8fa}.portal-top{height:70px;background:#fff;border-bottom:1px solid #d6e8ee;display:flex;align-items:center;justify-content:space-between;padding:0 24px;position:sticky;top:0;z-index:3}.portal-title{font-size:17px;font-weight:800;color:#0a4d68}.userbox{display:flex;align-items:center;gap:10px;font-size:11px;color:#315e6e}.avatar2{width:36px;height:36px;border-radius:50%;background:#0d6e6e;color:#fff;display:grid;place-items:center;font-weight:800}.content-wrap{padding:18px}.dashboard-welcome{background:#eaf7f8;border:1px solid #d3e9ed;border-radius:10px;padding:18px;margin-bottom:16px}.dashboard-welcome h2{margin:0 0 5px;color:#0a4d68;font-size:22px}.dashboard-welcome p{margin:0;color:#66869a;font-size:12px}.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:16px}.stat-card{background:#fff;border:1px solid #d6e8ee;border-radius:10px;padding:18px;box-shadow:0 3px 12px rgba(10,77,104,.04)}.stat-card small{display:block;color:#66869a;font-size:11px;margin-bottom:8px}.stat-card strong{font-size:24px;color:#0a4d68}.quick{background:#fff;border:1px solid #d6e8ee;border-radius:10px;padding:18px}.quick h3{margin:0 0 14px;color:#164e63}.quick-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.quick a{padding:13px;border:1px solid #d6e8ee;border-radius:8px;color:#315e6e;font-size:12px;font-weight:700;background:#fbfdfe}.quick a:hover{background:#eaf6f8;color:#0d6e6e}.framewrap{height:calc(100vh - 106px)}iframe{width:100%;height:100%;border:1px solid #d6e8ee;border-radius:10px;background:#fff}.module-note{font-size:9px;color:#bde1e6;padding:10px 12px 3px;text-transform:uppercase;letter-spacing:.08em}@media(max-width:1000px){.stat-grid{grid-template-columns:repeat(2,1fr)}.quick-grid{grid-template-columns:1fr 1fr}}
</style></head><body class="app-page">
<aside class="sidebar"><div class="sidebar-brand"><img src="assets/logo.png"><div><strong>RS <span>Suka</span> Sehat</strong><small>SIMRS Terintegrasi</small></div></div><div class="module-note">MENU <?=htmlspecialchars(strtoupper($cfg['title']))?></div><nav class="sidebar-nav">
<?php foreach($menus as $m): ?><a class="nav-item <?=$m[0]===$current[0]?'active':''?>" href="?page=<?=urlencode($m[0])?>"><span><?=$m[2]?></span><?=htmlspecialchars($m[1])?></a><?php endforeach; ?>
<a class="nav-item" href="logout.php"><span>↪</span>Logout</a></nav></aside>
<main class="main-content"><header class="portal-top"><div class="portal-title"><?=htmlspecialchars($current[1])?></div><div class="userbox"><div style="text-align:right"><b><?=htmlspecialchars($u['name'])?></b><br><?=htmlspecialchars($u['role_label'])?></div><div class="avatar2"><?=strtoupper(substr($u['name'],0,1))?></div></div></header>
<div class="content-wrap">
<?php if($isDashboard): ?>
<div class="dashboard-welcome"><h2>Selamat datang, <?=htmlspecialchars($u['name'])?>!</h2><p>Dashboard SIMRS RS Suka Sehat · <?=htmlspecialchars($u['role_label'])?></p></div>
<div class="stat-grid"><?php foreach($s as $x): ?><div class="stat-card"><small><?=htmlspecialchars($x[0])?></small><strong><?=htmlspecialchars($x[1])?></strong></div><?php endforeach; ?></div>
<div class="quick"><h3>Akses Cepat</h3><div class="quick-grid"><?php foreach(array_slice($menus,1) as $m): ?><a href="?page=<?=urlencode($m[0])?>"><span style="margin-right:8px"><?=$m[2]?></span><?=htmlspecialchars($m[1])?></a><?php endforeach; ?></div></div>
<?php else: ?>
<div class="framewrap"><iframe id="moduleFrame" src="<?=htmlspecialchars($current[3])?>"></iframe></div>
<script>
const frame=document.getElementById('moduleFrame');
frame.addEventListener('load',()=>{
  try{
    const d=frame.contentDocument, w=frame.contentWindow;
    const st=d.createElement('style');
    st.textContent=`body{background:#f3f8fa!important} aside,.sidebar,.side,header.topbar,.topbar,.top{display:none!important}.main,.main-content{margin-left:0!important}.layout{display:block!important}.content{padding:18px!important}.shell{display:block!important} .app{display:block!important}`;
    d.head.appendChild(st);
    const action=<?=json_encode($current[4]??'')?>;
    if(action){ setTimeout(()=>{ try{ w.eval(action); }catch(e){} },120); }
  }catch(e){}
});
</script>
<?php endif; ?>
</div></main></body></html>
