<?php
session_start();

if (isset($_SESSION['user'])) {

    if ($_SESSION['user']['role'] === 'radiologist') {
        header('Location: dashboard_radiolog.php');
        exit;
    }

    if ($_SESSION['user']['role'] === 'admin') {
        header('Location: dashboard_admin.php');
        exit;
    }

    header('Location: dashboard.php');
    exit;
}

/*
 * DEMO ACCOUNTS
 * Tidak membutuhkan MySQL / phpMyAdmin.
 */
$accounts = [
    'petugas' => [
        'password' => 'petugas123',
        'name' => 'Andi Putra',
        'role' => 'petugas_registrasi',
        'role_label' => 'Petugas Registrasi'
    ],
    'radiolog' => [
        'password' => 'radiolog123',
        'name' => 'dr. Andi Pratama',
        'role' => 'radiologist',
        'role_label' => 'Dokter Radiologi'
    ],
    'admin' => [
        'password' => 'admin123',
        'name' => 'Administrator',
        'role' => 'admin',
        'role_label' => 'Administrator'
    ]
];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (isset($accounts[$username]) && hash_equals($accounts[$username]['password'], $password)) {
        $_SESSION['user'] = [
    'username' => $username,
    'name' => $accounts[$username]['name'],
    'role' => $accounts[$username]['role'],
    'role_label' => $accounts[$username]['role_label']
];

/* Arahkan berdasarkan role */
if ($accounts[$username]['role'] === 'radiologist') {
    header('Location: dashboard_radiolog.php');
    exit;
}

if ($accounts[$username]['role'] === 'admin') {
    header('Location: dashboard_admin.php');
    exit;
}

/* Petugas registrasi */
header('Location: dashboard.php');
exit;
    }

    $error = 'Username atau password salah.';
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - RS Suka Sehat</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="login-page">

<div class="decor decor-1">+</div>
<div class="decor decor-2">+</div>
<div class="login-wave"></div>

<main class="login-container">
    <div class="brand">
        <img src="assets/logo.png" alt="Logo RS Suka Sehat">
        <div>
            <div class="brand-name">RS <span>Suka</span> Sehat</div>
            <div class="brand-subtitle">Sistem Informasi Manajemen Rumah Sakit</div>
        </div>
    </div>

    <section class="login-card">
        <h1>Masuk ke Akun Anda</h1>
        <p class="login-description">
            Silakan masuk menggunakan<br>
            username dan password Anda.
        </p>

        <?php if ($error): ?>
            <div class="error-box">⚠ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <label for="username">Username</label>
            <div class="input-wrap">
                <span>♙</span>
                <input id="username" name="username" type="text"
                       placeholder="Masukkan username" required autofocus>
            </div>

            <label for="password">Password</label>
            <div class="input-wrap">
                <span>👁️</span>
                <input id="password" name="password" type="password"
                       placeholder="Masukkan password" required>
                <button type="button" class="eye"
                        onclick="togglePassword()">◉</button>
            </div>

            <div class="forgot-row">
                <a href="#" onclick="alert('Silakan hubungi administrator rumah sakit untuk reset password.'); return false;">
                    Lupa Sandi?
                </a>
            </div>

            <button class="login-button" type="submit">Login</button>
        </form>

        <div class="demo-box">
            <h3>Akun Demo</h3>

            <div class="demo-account">
                <strong>Petugas Registrasi</strong>
                <span>Username: <b>petugas</b> | Password: <b>petugas123</b></span>
            </div>

            <div class="demo-account">
                <strong>Dokter Radiologi</strong>
                <span>Username: <b>radiolog</b> | Password: <b>radiolog123</b></span>
            </div>

            <div class="demo-account">
                <strong>Administrator</strong>
                <span>Username: <b>admin</b> | Password: <b>admin123</b></span>
            </div>
        </div>
    </section>

    <footer>
        © 2026 RS Suka Sehat<br>
        <span>Melayani dengan Sepenuh Hati!</span>
    </footer>
</main>

<script>
function togglePassword() {
    const input = document.getElementById('password');
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>

</body>
</html>
