import { useState } from "react";
import type { UserInfo } from "../types/user";
import logoSrc from "../assets/logo.png";

interface PerawatProps {
  user: UserInfo;
  onLogout: () => void;
}

type PerawatView = "dashboard" | "vitals" | "catatan" | "obat" | "observasi";

type TriageLevel = "P1" | "P2" | "P3" | "P4";
type PatientStatus = "kritis" | "stabil" | "membaik" | "observasi";
type MedStatus = "belum" | "diberikan" | "ditunda" | "skip";
type ObsShift = "pagi" | "siang" | "malam";

interface WardPatient {
  id: string;
  rm: string;
  name: string;
  age: number;
  gender: "L" | "P";
  room: string;
  bed: string;
  diagnosis: string;
  icd: string;
  admitDate: string;
  days: number;
  triage: TriageLevel;
  status: PatientStatus;
  insurance: string;
  doctor: string;
  lastVital?: string;
  alert?: string;
}

interface VitalRecord {
  id: string;
  patientId: string;
  time: string;
  nurse: string;
  bp: string;
  hr: number;
  rr: number;
  temp: number;
  spo2: number;
  pain: number;
  gcs: number;
  notes: string;
}

interface NursingNote {
  id: string;
  patientId: string;
  time: string;
  nurse: string;
  shift: ObsShift;
  category: string;
  note: string;
  followUp: string;
}

interface Medication {
  id: string;
  patientId: string;
  drug: string;
  dose: string;
  route: string;
  frequency: string;
  times: string[];
  status: MedStatus[];
  prescribedBy: string;
}

interface ObsEntry {
  id: string;
  patientId: string;
  shift: ObsShift;
  date: string;
  nurse: string;
  generalCondition: string;
  consciousness: string;
  diet: string;
  elimination: string;
  mobility: string;
  pain: string;
  notes: string;
}

// ── Seed data ─────────────────────────────────────────────────────────────────

const PATIENTS: WardPatient[] = [
  { id: "p1", rm: "RM-2026-000219", name: "Herman Suryadi", age: 67, gender: "L", room: "VIP-01", bed: "VIP-01A", diagnosis: "Gagal Jantung Kongestif", icd: "I50.0", admitDate: "16/07/2026", days: 71, triage: "P1", status: "stabil", insurance: "BPJS", doctor: "dr. Ahmad Fauzi, Sp.PD", lastVital: "10 mnt lalu", alert: "Pantau intake cairan" },
  { id: "p2", rm: "RM-2026-000220", name: "Siti Nurhaliza", age: 54, gender: "P", room: "Kelas I-01", bed: "I-01A", diagnosis: "Diabetes Mellitus Tipe 2", icd: "E11", admitDate: "20/08/2026", days: 36, triage: "P2", status: "membaik", insurance: "BPJS", doctor: "dr. Rina Soekartini, Sp.PD", lastVital: "1 jam lalu" },
  { id: "p3", rm: "RM-2026-000221", name: "Bambang Irawan", age: 45, gender: "L", room: "Kelas I-04", bed: "I-04A", diagnosis: "Pneumonia", icd: "J18.9", admitDate: "01/09/2026", days: 24, triage: "P2", status: "observasi", insurance: "Mandiri", doctor: "dr. Budi Hartono, Sp.P", lastVital: "30 mnt lalu", alert: "Saturasi rendah kemarin" },
  { id: "p4", rm: "RM-2026-000222", name: "Wati Susanti", age: 38, gender: "P", room: "Kelas II-04", bed: "II-04A", diagnosis: "Post Op Appendektomi", icd: "Z48.0", admitDate: "05/09/2026", days: 20, triage: "P3", status: "membaik", insurance: "Asuransi Swasta", doctor: "dr. Andi Wijaya, Sp.B", lastVital: "2 jam lalu" },
  { id: "p5", rm: "RM-2026-000223", name: "Joko Widodo", age: 59, gender: "L", room: "Kelas III-02", bed: "III-02A", diagnosis: "Hipertensi Grade II", icd: "I10", admitDate: "04/09/2026", days: 21, triage: "P3", status: "stabil", insurance: "BPJS", doctor: "dr. Ahmad Fauzi, Sp.PD", lastVital: "3 jam lalu" },
  { id: "p6", rm: "RM-2026-000224", name: "Ahmad Rizal", age: 72, gender: "L", room: "ICU-01", bed: "ICU-01", diagnosis: "Stroke Iskemik", icd: "I63.9", admitDate: "06/09/2026", days: 19, triage: "P1", status: "kritis", insurance: "BPJS", doctor: "dr. Candra Utama, Sp.S", lastVital: "5 mnt lalu", alert: "Monitor ketat — GCS turun" },
];

const VITALS_HISTORY: VitalRecord[] = [
  { id: "v1", patientId: "p6", time: "07:00", nurse: "Ns. Rina", bp: "180/100", hr: 98, rr: 22, temp: 37.8, spo2: 94, pain: 0, gcs: 9, notes: "Pasien tidak sadar penuh" },
  { id: "v2", patientId: "p1", time: "08:00", nurse: "Ns. Rina", bp: "130/80", hr: 78, rr: 18, temp: 36.8, spo2: 97, pain: 2, gcs: 15, notes: "Edema pergelangan masih ada" },
  { id: "v3", patientId: "p3", time: "09:00", nurse: "Ns. Dewi", bp: "120/75", hr: 90, rr: 24, temp: 38.2, spo2: 95, pain: 3, gcs: 15, notes: "Batuk produktif" },
];

const MEDICATIONS: Medication[] = [
  { id: "m1", patientId: "p1", drug: "Furosemide", dose: "40 mg", route: "IV", frequency: "2x sehari", times: ["06:00", "18:00"], status: ["diberikan", "belum"], prescribedBy: "dr. Ahmad Fauzi" },
  { id: "m2", patientId: "p1", drug: "Spironolakton", dose: "25 mg", route: "Oral", frequency: "1x sehari", times: ["08:00"], status: ["diberikan"], prescribedBy: "dr. Ahmad Fauzi" },
  { id: "m3", patientId: "p3", drug: "Amoksisilin", dose: "500 mg", route: "IV", frequency: "3x sehari", times: ["06:00", "14:00", "22:00"], status: ["diberikan", "diberikan", "belum"], prescribedBy: "dr. Budi Hartono" },
  { id: "m4", patientId: "p6", drug: "Alteplase", dose: "0.9 mg/kg", route: "IV", frequency: "1x", times: ["08:00"], status: ["diberikan"], prescribedBy: "dr. Candra Utama" },
  { id: "m5", patientId: "p6", drug: "Aspirin", dose: "80 mg", route: "Oral", frequency: "1x sehari", times: ["08:00"], status: ["belum"], prescribedBy: "dr. Candra Utama" },
  { id: "m6", patientId: "p2", drug: "Metformin", dose: "500 mg", route: "Oral", frequency: "2x sehari", times: ["07:00", "19:00"], status: ["diberikan", "belum"], prescribedBy: "dr. Rina Soekartini" },
];

const NURSING_NOTES: NursingNote[] = [
  { id: "n1", patientId: "p6", time: "07:30", nurse: "Ns. Rina", shift: "pagi", category: "Neurologi", note: "GCS E2V2M5, pupil anisokor kanan lebih lebar. Segera lapor DPJP.", followUp: "Laporan sudah disampaikan ke dr. Candra" },
  { id: "n2", patientId: "p1", time: "08:15", nurse: "Ns. Rina", shift: "pagi", category: "Kardiovaskular", note: "Edema bilateral grade 2. Balance cairan -200 mL dari target.", followUp: "Lanjutkan pembatasan cairan 1000 mL/24 jam" },
  { id: "n3", patientId: "p3", time: "09:30", nurse: "Ns. Dewi", shift: "pagi", category: "Respirasi", note: "SpO2 membaik ke 96% setelah nebulisasi. Batuk berkurang.", followUp: "Nebulisasi ulang jam 13:00" },
];

const OBS_ENTRIES: ObsEntry[] = [
  { id: "o1", patientId: "p1", shift: "pagi", date: "07/09/2026", nurse: "Ns. Rina", generalCondition: "Lemah, composmentis", consciousness: "Composmentis, GCS 15", diet: "Habis 3/4 porsi, diet rendah garam", elimination: "BAK 400 mL/6 jam, BAB belum", mobility: "Bed rest dengan bantuan", pain: "Skala 2/10 — nyeri ringan", notes: "Pantau edema dan output urin tiap jam" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────

const TRIAGE_STYLE: Record<TriageLevel, { bg: string; color: string; label: string }> = {
  P1: { bg: "#fee2e2", color: "#dc2626", label: "P1 – Kritis" },
  P2: { bg: "#fef9c3", color: "#d97706", label: "P2 – Darurat" },
  P3: { bg: "#dcfce7", color: "#16a34a", label: "P3 – Segera" },
  P4: { bg: "#dbeafe", color: "#2563eb", label: "P4 – Minor" },
};

const STATUS_STYLE: Record<PatientStatus, { bg: string; color: string; label: string; dot: string }> = {
  kritis:    { bg: "#fee2e2", color: "#dc2626", label: "Kritis",   dot: "#dc2626" },
  stabil:    { bg: "#dbeafe", color: "#2563eb", label: "Stabil",   dot: "#2563eb" },
  membaik:   { bg: "#dcfce7", color: "#16a34a", label: "Membaik",  dot: "#16a34a" },
  observasi: { bg: "#fef9c3", color: "#d97706", label: "Observasi",dot: "#d97706" },
};

const MED_STYLE: Record<MedStatus, { bg: string; color: string; label: string }> = {
  belum:     { bg: "#fef9c3", color: "#d97706", label: "Belum" },
  diberikan: { bg: "#dcfce7", color: "#16a34a", label: "✓ OK" },
  ditunda:   { bg: "#dbeafe", color: "#2563eb", label: "Ditunda" },
  skip:      { bg: "#fee2e2", color: "#dc2626", label: "Skip" },
};

const SHIFT_LABEL: Record<ObsShift, string> = { pagi: "Pagi (06-14)", siang: "Siang (14-22)", malam: "Malam (22-06)" };

const NOTE_CATS = ["Neurologi", "Kardiovaskular", "Respirasi", "Gastrointestinal", "Musculoskeletal", "Psikososial", "Luka & Integritas Kulit", "Lainnya"];

const SIDEBAR: { key: PerawatView; label: string; icon: string }[] = [
  { key: "dashboard",  label: "Dashboard Bangsal",   icon: "📊" },
  { key: "vitals",     label: "Tanda Vital",          icon: "💓" },
  { key: "catatan",    label: "Catatan Keperawatan",  icon: "📋" },
  { key: "obat",       label: "Pemberian Obat",       icon: "💊" },
  { key: "observasi",  label: "Observasi Pasien",     icon: "👁" },
];

function nowTime() { return new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }); }

// ── Component ─────────────────────────────────────────────────────────────────

export default function Perawat({ user, onLogout }: PerawatProps) {
  const [view, setView]           = useState<PerawatView>("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [notif]                   = useState(3);

  const [patients]                = useState<WardPatient[]>(PATIENTS);
  const [vitals, setVitals]       = useState<VitalRecord[]>(VITALS_HISTORY);
  const [meds, setMeds]           = useState<Medication[]>(MEDICATIONS);
  const [notes, setNotes]         = useState<NursingNote[]>(NURSING_NOTES);
  const [obs, setObs]             = useState<ObsEntry[]>(OBS_ENTRIES);

  const [toast, setToast]         = useState<string | null>(null);
  const [selectedPid, setSelectedPid] = useState<string>("p1");

  // Vital form
  const [vForm, setVForm] = useState({ bp: "", hr: "", rr: "", temp: "", spo2: "", pain: "0", gcs: "15", notes: "" });
  const [vErrors, setVErrors] = useState<Record<string, string>>({});

  // Note form
  const [noteForm, setNoteForm] = useState({ category: "Kardiovaskular", shift: "pagi" as ObsShift, note: "", followUp: "" });
  const [noteErrors, setNoteErrors] = useState<Record<string, string>>({});

  // Obs form
  const [obsForm, setObsForm] = useState({ shift: "pagi" as ObsShift, generalCondition: "", consciousness: "", diet: "", elimination: "", mobility: "", pain: "", notes: "" });
  const [obsErrors, setObsErrors] = useState<Record<string, string>>({});

  // Filters
  const [medPatientId, setMedPatientId] = useState("p1");
  const [notePatientId, setNotePatientId] = useState("p1");
  const [obsPatientId, setObsPatientId] = useState("p1");

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }

  const selectedPatient = patients.find((p) => p.id === selectedPid)!;

  // ── Vital submit ──────────────────────────────────────────────────────────
  function submitVital() {
    const e: Record<string, string> = {};
    if (!vForm.bp.match(/^\d{2,3}\/\d{2,3}$/)) e.bp = "Format TD: sistolik/diastolik (mis. 120/80)";
    if (!vForm.hr || Number(vForm.hr) < 30 || Number(vForm.hr) > 250) e.hr = "Nadi harus antara 30-250 bpm";
    if (!vForm.rr || Number(vForm.rr) < 5 || Number(vForm.rr) > 60) e.rr = "RR harus antara 5-60 x/mnt";
    if (!vForm.temp || Number(vForm.temp) < 35 || Number(vForm.temp) > 42) e.temp = "Suhu 35–42 °C";
    if (!vForm.spo2 || Number(vForm.spo2) < 50 || Number(vForm.spo2) > 100) e.spo2 = "SpO₂ 50–100 %";
    if (Object.keys(e).length) { setVErrors(e); return; }

    const v: VitalRecord = {
      id: String(Date.now()), patientId: selectedPid, time: nowTime(), nurse: user.fullName,
      bp: vForm.bp, hr: Number(vForm.hr), rr: Number(vForm.rr), temp: Number(vForm.temp),
      spo2: Number(vForm.spo2), pain: Number(vForm.pain), gcs: Number(vForm.gcs), notes: vForm.notes,
    };
    setVitals((prev) => [v, ...prev]);
    setVForm({ bp: "", hr: "", rr: "", temp: "", spo2: "", pain: "0", gcs: "15", notes: "" });
    setVErrors({});
    showToast(`Tanda vital ${selectedPatient.name} berhasil disimpan`);
  }

  // ── Note submit ───────────────────────────────────────────────────────────
  function submitNote() {
    const e: Record<string, string> = {};
    if (!noteForm.note.trim()) e.note = "Catatan tidak boleh kosong";
    if (Object.keys(e).length) { setNoteErrors(e); return; }

    const n: NursingNote = {
      id: String(Date.now()), patientId: notePatientId, time: nowTime(), nurse: user.fullName,
      shift: noteForm.shift, category: noteForm.category, note: noteForm.note, followUp: noteForm.followUp,
    };
    setNotes((prev) => [n, ...prev]);
    setNoteForm({ category: "Kardiovaskular", shift: "pagi", note: "", followUp: "" });
    setNoteErrors({});
    showToast("Catatan keperawatan berhasil disimpan");
  }

  // ── Obs submit ────────────────────────────────────────────────────────────
  function submitObs() {
    const e: Record<string, string> = {};
    if (!obsForm.generalCondition.trim()) e.generalCondition = "Kondisi umum wajib diisi";
    if (Object.keys(e).length) { setObsErrors(e); return; }

    const entry: ObsEntry = {
      id: String(Date.now()), patientId: obsPatientId, shift: obsForm.shift,
      date: new Date().toLocaleDateString("id-ID"), nurse: user.fullName,
      generalCondition: obsForm.generalCondition, consciousness: obsForm.consciousness,
      diet: obsForm.diet, elimination: obsForm.elimination, mobility: obsForm.mobility,
      pain: obsForm.pain, notes: obsForm.notes,
    };
    setObs((prev) => [entry, ...prev]);
    setObsForm({ shift: "pagi", generalCondition: "", consciousness: "", diet: "", elimination: "", mobility: "", pain: "", notes: "" });
    setObsErrors({});
    showToast("Observasi berhasil dicatat");
  }

  // ── Med toggle ────────────────────────────────────────────────────────────
  function toggleMed(medId: string, idx: number) {
    setMeds((prev) => prev.map((m) => {
      if (m.id !== medId) return m;
      const ns = [...m.status];
      ns[idx] = ns[idx] === "belum" ? "diberikan" : "belum";
      return { ...m, status: ns };
    }));
    showToast("Status pemberian obat diperbarui");
  }

  // ── Derived ───────────────────────────────────────────────────────────────
  const kritisCount  = patients.filter((p) => p.status === "kritis").length;
  const stabil       = patients.filter((p) => p.status === "stabil").length;
  const membaik      = patients.filter((p) => p.status === "membaik").length;
  const obsCount     = patients.filter((p) => p.status === "observasi").length;

  const pendingMeds  = meds.filter((m) => m.status.some((s) => s === "belum")).length;

  const patientVitals   = vitals.filter((v) => v.patientId === selectedPid);
  const patientNotes    = notes.filter((n) => n.patientId === notePatientId);
  const patientMeds     = meds.filter((m) => m.patientId === medPatientId);
  const patientObs      = obs.filter((o) => o.patientId === obsPatientId);

  // ── Patient picker row ────────────────────────────────────────────────────
  function PatientPicker({ value, onChange }: { value: string; onChange: (id: string) => void }) {
    return (
      <div className="flex gap-2 flex-wrap">
        {patients.map((p) => {
          const ts = TRIAGE_STYLE[p.triage];
          const active = value === p.id;
          return (
            <button key={p.id} onClick={() => onChange(p.id)}
              className="flex items-center gap-2 px-3 py-2 rounded-xl border-2 text-left transition-all"
              style={{ background: active ? "#e0f2fe" : "#fff", borderColor: active ? "#0f7490" : "#e2e8f0" }}>
              <span className="text-xs font-bold px-1.5 py-0.5 rounded" style={{ background: ts.bg, color: ts.color }}>{p.triage}</span>
              <div>
                <p className="text-xs font-semibold" style={{ color: "#1e293b" }}>{p.name}</p>
                <p className="text-xs" style={{ color: "#94a3b8" }}>{p.room}</p>
              </div>
              {p.alert && <span style={{ color: "#dc2626", fontSize: 14 }}>⚠</span>}
            </button>
          );
        })}
      </div>
    );
  }

  // ──────────────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <header className="flex items-center justify-between px-5 shrink-0 border-b"
        style={{ height: 52, background: "#0f7490", borderColor: "#0c5f75" }}>
        <div className="flex items-center gap-3">
          <button onClick={() => setCollapsed((c) => !c)} className="text-white/70 hover:text-white p-1">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <rect y="3"    width="18" height="1.5" rx=".75" fill="currentColor" />
              <rect y="8.25" width="18" height="1.5" rx=".75" fill="currentColor" />
              <rect y="13.5" width="18" height="1.5" rx=".75" fill="currentColor" />
            </svg>
          </button>
          <img src={logoSrc} alt="logo" className="w-8 h-8 rounded-full" style={{ background: "#fff" }} />
          <span className="text-white font-bold text-sm tracking-wide">RS SUKA SEHAT</span>
          <span className="hidden md:inline text-white/40 text-xs">— Perawat / Bidan</span>
        </div>
        <div className="flex items-center gap-3">
          <button className="relative text-white/70 hover:text-white">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </svg>
            {notif > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full flex items-center justify-center text-white"
                style={{ background: "#dc2626", fontSize: "9px" }}>{notif}</span>
            )}
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
              style={{ background: "rgba(255,255,255,0.2)" }}>{user.initials}</div>
            <div className="hidden sm:block">
              <p className="text-white text-xs font-semibold leading-tight">{user.fullName}</p>
              <p className="text-white/60 text-xs leading-tight">Perawat — {user.unit}</p>
            </div>
          </div>
          <button onClick={onLogout} className="text-xs px-2.5 py-1 rounded font-medium text-white"
            style={{ background: "#dc2626" }}>Keluar</button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="flex flex-col shrink-0 border-r transition-all duration-200"
          style={{ width: collapsed ? 52 : 216, background: "#fff", borderColor: "#e2e8f0" }}>
          {!collapsed && (
            <div className="px-3 pt-4 pb-2">
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#94a3b8" }}>Keperawatan</p>
            </div>
          )}
          <nav className="flex-1 p-2 space-y-0.5">
            {SIDEBAR.map((item) => {
              const active = view === item.key;
              return (
                <button key={item.key} onClick={() => setView(item.key)}
                  className="w-full flex items-center gap-2.5 rounded-lg px-2.5 py-2.5 text-left transition-all"
                  style={{ background: active ? "#e0f2fe" : "transparent", color: active ? "#0f7490" : "#475569" }}>
                  <span className="text-base shrink-0">{item.icon}</span>
                  {!collapsed && <span className="text-xs font-semibold">{item.label}</span>}
                  {item.key === "obat" && pendingMeds > 0 && !collapsed && (
                    <span className="ml-auto text-xs font-bold px-1.5 py-0.5 rounded-full text-white"
                      style={{ background: "#dc2626", fontSize: "9px" }}>{pendingMeds}</span>
                  )}
                  {active && !collapsed && <span className="w-1.5 h-1.5 rounded-full ml-auto" style={{ background: "#0f7490" }} />}
                </button>
              );
            })}
          </nav>
          {!collapsed && (
            <div className="p-3 border-t mx-2 mb-2 rounded-lg" style={{ borderColor: "#e2e8f0", background: "#f8fafc" }}>
              <p className="text-xs font-semibold" style={{ color: "#334155" }}>{user.fullName}</p>
              <p className="text-xs mt-0.5" style={{ color: "#94a3b8" }}>Perawat · {user.unit}</p>
            </div>
          )}
        </aside>

        {/* Main */}
        <main className="flex-1 overflow-y-auto" style={{ background: "#f0f4f7" }}>

          {/* ════ DASHBOARD ════ */}
          {view === "dashboard" && (
            <div className="p-6 space-y-5">
              <div>
                <h1 className="text-xl font-bold" style={{ color: "#1e293b" }}>Dashboard Bangsal</h1>
                <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>
                  Shift Pagi · {new Date().toLocaleDateString("id-ID", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                </p>
              </div>

              {/* KPIs */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "Total Pasien Bangsal",   val: String(patients.length),  sub: "di bawah perawatan", icon: "🛏", accent: "#0f7490", bg: "#e0f2fe" },
                  { label: "Kondisi Kritis",          val: String(kritisCount),       sub: "butuh perhatian khusus", icon: "🚨", accent: "#dc2626", bg: "#fee2e2" },
                  { label: "Observasi Ketat",         val: String(obsCount),          sub: "dalam pemantauan", icon: "👁",  accent: "#d97706", bg: "#fef9c3" },
                  { label: "Obat Belum Diberikan",    val: String(pendingMeds),       sub: "item menunggu", icon: "💊", accent: "#d97706", bg: "#fef9c3" },
                ].map((k) => (
                  <div key={k.label} className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                    <div className="flex items-start justify-between mb-3">
                      <p className="text-xs font-medium" style={{ color: "#64748b" }}>{k.label}</p>
                      <span className="w-9 h-9 rounded-lg flex items-center justify-center text-lg" style={{ background: k.bg }}>{k.icon}</span>
                    </div>
                    <p className="text-3xl font-bold" style={{ fontFamily: "var(--font-mono)", color: k.accent }}>{k.val}</p>
                    <p className="text-xs mt-1" style={{ color: "#94a3b8" }}>{k.sub}</p>
                  </div>
                ))}
              </div>

              {/* Status overview + alerts */}
              <div className="grid grid-cols-3 gap-5">
                {/* Patient list */}
                <div className="col-span-2 rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                  <div className="px-5 py-4 border-b flex items-center justify-between" style={{ borderColor: "#e2e8f0" }}>
                    <h2 className="text-sm font-semibold" style={{ color: "#1e293b" }}>Daftar Pasien Bangsal</h2>
                    <div className="flex gap-2 text-xs">
                      {[{ label: "Kritis", count: kritisCount, color: "#dc2626" }, { label: "Observasi", count: obsCount, color: "#d97706" }, { label: "Stabil", count: stabil, color: "#2563eb" }, { label: "Membaik", count: membaik, color: "#16a34a" }].map((s) => (
                        <span key={s.label} className="flex items-center gap-1 px-2 py-1 rounded-full" style={{ background: "#f8fafc" }}>
                          <span className="w-2 h-2 rounded-full" style={{ background: s.color }} />
                          <span style={{ color: "#64748b" }}>{s.label} {s.count}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="divide-y" style={{ borderColor: "#f1f5f9" }}>
                    {patients.map((p) => {
                      const ts = TRIAGE_STYLE[p.triage];
                      const ss = STATUS_STYLE[p.status];
                      return (
                        <div key={p.id}
                          className="flex items-center gap-4 px-5 py-3 hover:bg-slate-50 transition-colors cursor-pointer"
                          onClick={() => { setSelectedPid(p.id); setView("vitals"); }}>
                          <div className="flex flex-col items-center gap-1 shrink-0">
                            <span className="text-xs font-bold px-1.5 py-0.5 rounded" style={{ background: ts.bg, color: ts.color }}>{p.triage}</span>
                            <span className="text-xs" style={{ color: "#94a3b8", fontFamily: "var(--font-mono)" }}>{p.room}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-semibold" style={{ color: "#1e293b" }}>{p.name}</p>
                              {p.alert && <span className="text-xs px-1.5 py-0.5 rounded font-medium" style={{ background: "#fee2e2", color: "#dc2626" }}>⚠ Alert</span>}
                            </div>
                            <p className="text-xs truncate" style={{ color: "#64748b" }}>{p.diagnosis} · {p.days} hr rawat · {p.doctor}</p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="flex items-center gap-1 text-xs font-medium">
                              <span className="w-1.5 h-1.5 rounded-full" style={{ background: ss.dot }} />
                              <span style={{ color: ss.color }}>{ss.label}</span>
                            </span>
                            {p.lastVital && <span className="text-xs px-2 py-0.5 rounded" style={{ background: "#f1f5f9", color: "#94a3b8" }}>TTV {p.lastVital}</span>}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Alert & recent vitals */}
                <div className="space-y-4">
                  {/* Alerts */}
                  <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                    <div className="px-4 py-3 border-b" style={{ borderColor: "#e2e8f0", background: "#fef9c3" }}>
                      <h3 className="text-xs font-bold" style={{ color: "#d97706" }}>⚠ Peringatan Aktif</h3>
                    </div>
                    <div className="divide-y" style={{ borderColor: "#f1f5f9" }}>
                      {patients.filter((p) => p.alert).map((p) => (
                        <div key={p.id} className="p-3">
                          <p className="text-xs font-semibold" style={{ color: "#1e293b" }}>{p.name}</p>
                          <p className="text-xs mt-0.5" style={{ color: "#dc2626" }}>{p.alert}</p>
                          <p className="text-xs mt-0.5" style={{ color: "#94a3b8" }}>{p.room}</p>
                        </div>
                      ))}
                      {patients.filter((p) => p.alert).length === 0 && (
                        <p className="p-4 text-xs text-center" style={{ color: "#94a3b8" }}>Tidak ada peringatan</p>
                      )}
                    </div>
                  </div>

                  {/* Pending meds */}
                  <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                    <div className="px-4 py-3 border-b" style={{ borderColor: "#e2e8f0" }}>
                      <h3 className="text-xs font-bold" style={{ color: "#1e293b" }}>💊 Obat Belum Diberikan</h3>
                    </div>
                    <div className="divide-y" style={{ borderColor: "#f1f5f9" }}>
                      {meds.filter((m) => m.status.some((s) => s === "belum")).map((m) => {
                        const patient = patients.find((p) => p.id === m.patientId);
                        const pendingIdx = m.status.map((s, i) => s === "belum" ? i : -1).filter((i) => i !== -1);
                        return (
                          <div key={m.id} className="p-3">
                            <p className="text-xs font-semibold" style={{ color: "#1e293b" }}>{m.drug} {m.dose}</p>
                            <p className="text-xs" style={{ color: "#64748b" }}>{patient?.name} · {m.times[pendingIdx[0]]} · {m.route}</p>
                          </div>
                        );
                      })}
                    </div>
                    <div className="px-3 pb-3">
                      <button onClick={() => setView("obat")} className="w-full text-xs py-1.5 rounded-lg border font-medium"
                        style={{ borderColor: "#e2e8f0", color: "#0f7490" }}>Kelola Pemberian Obat →</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ════ TANDA VITAL ════ */}
          {view === "vitals" && (
            <div className="p-6 space-y-5">
              <div>
                <h1 className="text-xl font-bold" style={{ color: "#1e293b" }}>Pengukuran Tanda Vital</h1>
                <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>Pilih pasien, masukkan hasil pengukuran</p>
              </div>

              {/* Patient picker */}
              <div className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                <p className="text-xs font-semibold mb-3" style={{ color: "#334155" }}>Pilih Pasien</p>
                <PatientPicker value={selectedPid} onChange={setSelectedPid} />
              </div>

              <div className="grid grid-cols-5 gap-5">
                {/* Form */}
                <div className="col-span-2 rounded-xl p-5 shadow-sm space-y-4" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                  <div>
                    <h2 className="text-sm font-semibold" style={{ color: "#1e293b" }}>Input Tanda Vital</h2>
                    <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>{selectedPatient?.name} · {selectedPatient?.room}</p>
                  </div>

                  {([
                    { key: "bp",   label: "Tekanan Darah (TD)", placeholder: "120/80", unit: "mmHg", hint: "Format: sistolik/diastolik" },
                    { key: "hr",   label: "Nadi (HR)", placeholder: "80", unit: "bpm", hint: "30–250" },
                    { key: "rr",   label: "Frekuensi Napas (RR)", placeholder: "18", unit: "x/mnt", hint: "5–60" },
                    { key: "temp", label: "Suhu Tubuh", placeholder: "36.5", unit: "°C", hint: "35.0–42.0" },
                    { key: "spo2", label: "Saturasi O₂ (SpO₂)", placeholder: "98", unit: "%", hint: "50–100" },
                  ] as const).map((f) => (
                    <div key={f.key}>
                      <label className="text-xs font-semibold block mb-1" style={{ color: "#334155" }}>{f.label} *</label>
                      <div className="relative">
                        <input className="w-full border rounded-lg px-3 py-2.5 pr-14 text-sm outline-none"
                          style={{ borderColor: vErrors[f.key] ? "#dc2626" : "#e2e8f0", color: "#334155", fontFamily: "var(--font-mono)" }}
                          placeholder={f.placeholder}
                          value={vForm[f.key as keyof typeof vForm]}
                          onChange={(e) => { setVForm((v) => ({ ...v, [f.key]: e.target.value })); setVErrors((ev) => ({ ...ev, [f.key]: "" })); }} />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs" style={{ color: "#94a3b8" }}>{f.unit}</span>
                      </div>
                      {vErrors[f.key] && <p className="text-xs mt-0.5" style={{ color: "#dc2626" }}>⚠ {vErrors[f.key]}</p>}
                    </div>
                  ))}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold block mb-1" style={{ color: "#334155" }}>Skala Nyeri (0–10)</label>
                      <select className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none"
                        style={{ borderColor: "#e2e8f0", color: "#334155", background: "#fff" }}
                        value={vForm.pain} onChange={(e) => setVForm((v) => ({ ...v, pain: e.target.value }))}>
                        {Array.from({ length: 11 }, (_, i) => <option key={i} value={i}>{i}{i === 0 ? " (Tidak Nyeri)" : i >= 8 ? " (Berat)" : ""}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs font-semibold block mb-1" style={{ color: "#334155" }}>GCS (3–15)</label>
                      <input type="number" min={3} max={15} className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none"
                        style={{ borderColor: "#e2e8f0", color: "#334155", fontFamily: "var(--font-mono)" }}
                        value={vForm.gcs} onChange={(e) => setVForm((v) => ({ ...v, gcs: e.target.value }))} />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold block mb-1" style={{ color: "#334155" }}>Catatan Tambahan</label>
                    <textarea rows={2} className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none resize-none"
                      style={{ borderColor: "#e2e8f0", color: "#334155" }}
                      placeholder="Kondisi tambahan yang perlu dicatat..."
                      value={vForm.notes} onChange={(e) => setVForm((v) => ({ ...v, notes: e.target.value }))} />
                  </div>

                  <button onClick={submitVital} className="w-full py-2.5 rounded-lg text-sm font-semibold text-white"
                    style={{ background: "#0f7490" }}>
                    💓 Simpan Tanda Vital
                  </button>
                </div>

                {/* History */}
                <div className="col-span-3 space-y-4">
                  {/* Latest vitals card */}
                  {patientVitals[0] && (
                    <div className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-sm font-semibold" style={{ color: "#1e293b" }}>Tanda Vital Terkini</h3>
                        <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "#dcfce7", color: "#16a34a" }}>
                          Diukur {patientVitals[0].time} · {patientVitals[0].nurse}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        {[
                          { label: "Tekanan Darah", val: patientVitals[0].bp, unit: "mmHg", icon: "🫀", warn: false },
                          { label: "Nadi", val: String(patientVitals[0].hr), unit: "bpm", icon: "💓", warn: patientVitals[0].hr > 100 || patientVitals[0].hr < 60 },
                          { label: "Pernapasan", val: String(patientVitals[0].rr), unit: "x/mnt", icon: "🌬", warn: patientVitals[0].rr > 20 },
                          { label: "Suhu", val: String(patientVitals[0].temp), unit: "°C", icon: "🌡", warn: patientVitals[0].temp > 37.5 },
                          { label: "SpO₂", val: String(patientVitals[0].spo2), unit: "%", icon: "🩸", warn: patientVitals[0].spo2 < 95 },
                          { label: "Skala Nyeri", val: String(patientVitals[0].pain), unit: "/10", icon: "😣", warn: patientVitals[0].pain >= 7 },
                        ].map((v) => (
                          <div key={v.label} className="rounded-lg p-3 text-center" style={{ background: v.warn ? "#fef9c3" : "#f8fafc" }}>
                            <p className="text-lg mb-1">{v.icon}</p>
                            <p className="text-xl font-bold" style={{ fontFamily: "var(--font-mono)", color: v.warn ? "#d97706" : "#0f7490" }}>{v.val}</p>
                            <p className="text-xs" style={{ color: "#94a3b8" }}>{v.unit}</p>
                            <p className="text-xs mt-0.5 font-medium" style={{ color: "#64748b" }}>{v.label}</p>
                            {v.warn && <p className="text-xs mt-0.5 font-bold" style={{ color: "#dc2626" }}>⚠ Abnormal</p>}
                          </div>
                        ))}
                      </div>
                      {patientVitals[0].notes && (
                        <p className="mt-3 text-xs p-2 rounded-lg" style={{ background: "#f1f5f9", color: "#64748b" }}>📝 {patientVitals[0].notes}</p>
                      )}
                    </div>
                  )}

                  {/* History table */}
                  <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                    <div className="px-5 py-4 border-b" style={{ borderColor: "#e2e8f0" }}>
                      <h3 className="text-sm font-semibold" style={{ color: "#1e293b" }}>Riwayat Tanda Vital</h3>
                    </div>
                    {patientVitals.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead>
                          <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
                            {["WAKTU", "TD", "HR", "RR", "SUHU", "SPO₂", "NYERI", "GCS", "PERAWAT"].map((h) => (
                              <th key={h} className="text-left text-xs font-semibold px-3 py-3" style={{ color: "#64748b" }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y" style={{ borderColor: "#f1f5f9" }}>
                          {patientVitals.map((v) => (
                            <tr key={v.id} className="hover:bg-slate-50">
                              <td className="px-3 py-2.5 text-xs" style={{ fontFamily: "var(--font-mono)", color: "#64748b" }}>{v.time}</td>
                              <td className="px-3 py-2.5 text-xs font-medium" style={{ fontFamily: "var(--font-mono)", color: "#334155" }}>{v.bp}</td>
                              <td className="px-3 py-2.5 text-xs" style={{ fontFamily: "var(--font-mono)", color: (v.hr > 100 || v.hr < 60) ? "#dc2626" : "#334155" }}>{v.hr}</td>
                              <td className="px-3 py-2.5 text-xs" style={{ fontFamily: "var(--font-mono)", color: v.rr > 20 ? "#dc2626" : "#334155" }}>{v.rr}</td>
                              <td className="px-3 py-2.5 text-xs" style={{ fontFamily: "var(--font-mono)", color: v.temp > 37.5 ? "#dc2626" : "#334155" }}>{v.temp}</td>
                              <td className="px-3 py-2.5 text-xs" style={{ fontFamily: "var(--font-mono)", color: v.spo2 < 95 ? "#dc2626" : "#334155" }}>{v.spo2}%</td>
                              <td className="px-3 py-2.5 text-xs text-center" style={{ color: v.pain >= 7 ? "#dc2626" : "#334155" }}>{v.pain}/10</td>
                              <td className="px-3 py-2.5 text-xs text-center" style={{ color: v.gcs < 12 ? "#dc2626" : "#334155" }}>{v.gcs}</td>
                              <td className="px-3 py-2.5 text-xs" style={{ color: "#94a3b8" }}>{v.nurse}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <p className="py-8 text-center text-sm" style={{ color: "#94a3b8" }}>Belum ada data tanda vital untuk pasien ini</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ════ CATATAN KEPERAWATAN ════ */}
          {view === "catatan" && (
            <div className="p-6 space-y-5">
              <div>
                <h1 className="text-xl font-bold" style={{ color: "#1e293b" }}>Catatan Keperawatan</h1>
                <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>Dokumentasi asuhan keperawatan berdasarkan SBAR / SOAP</p>
              </div>

              {/* Patient picker */}
              <div className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                <p className="text-xs font-semibold mb-3" style={{ color: "#334155" }}>Pilih Pasien</p>
                <PatientPicker value={notePatientId} onChange={setNotePatientId} />
              </div>

              <div className="grid grid-cols-5 gap-5">
                {/* Note form */}
                <div className="col-span-2 rounded-xl p-5 shadow-sm space-y-4" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                  <h2 className="text-sm font-semibold" style={{ color: "#1e293b" }}>Tambah Catatan Baru</h2>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5" style={{ color: "#334155" }}>Shift</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(["pagi", "siang", "malam"] as ObsShift[]).map((s) => (
                        <button key={s} onClick={() => setNoteForm((f) => ({ ...f, shift: s }))}
                          className="py-2 rounded-lg text-xs font-semibold border-2 capitalize"
                          style={{ background: noteForm.shift === s ? "#e0f2fe" : "#f8fafc", color: noteForm.shift === s ? "#0f7490" : "#64748b", borderColor: noteForm.shift === s ? "#0f7490" : "#e2e8f0" }}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5" style={{ color: "#334155" }}>Kategori</label>
                    <select className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none"
                      style={{ borderColor: "#e2e8f0", color: "#334155", background: "#fff" }}
                      value={noteForm.category} onChange={(e) => setNoteForm((f) => ({ ...f, category: e.target.value }))}>
                      {NOTE_CATS.map((c) => <option key={c}>{c}</option>)}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5" style={{ color: "#334155" }}>Catatan Keperawatan *</label>
                    <textarea rows={5} className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none resize-none"
                      style={{ borderColor: noteErrors.note ? "#dc2626" : "#e2e8f0", color: "#334155" }}
                      placeholder="Tuliskan observasi, intervensi, dan respons pasien..."
                      value={noteForm.note} onChange={(e) => { setNoteForm((f) => ({ ...f, note: e.target.value })); setNoteErrors((er) => ({ ...er, note: "" })); }} />
                    {noteErrors.note && <p className="text-xs mt-0.5" style={{ color: "#dc2626" }}>⚠ {noteErrors.note}</p>}
                  </div>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5" style={{ color: "#334155" }}>Tindak Lanjut / Rencana</label>
                    <textarea rows={2} className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none resize-none"
                      style={{ borderColor: "#e2e8f0", color: "#334155" }}
                      placeholder="Rencana asuhan keperawatan berikutnya..."
                      value={noteForm.followUp} onChange={(e) => setNoteForm((f) => ({ ...f, followUp: e.target.value }))} />
                  </div>

                  <button onClick={submitNote} className="w-full py-2.5 rounded-lg text-sm font-semibold text-white"
                    style={{ background: "#0f7490" }}>
                    📋 Simpan Catatan
                  </button>
                </div>

                {/* Notes list */}
                <div className="col-span-3 space-y-3">
                  {patientNotes.length > 0 ? patientNotes.map((n) => (
                    <div key={n.id} className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium text-white capitalize"
                            style={{ background: n.shift === "pagi" ? "#0f7490" : n.shift === "siang" ? "#d97706" : "#1e293b" }}>
                            {SHIFT_LABEL[n.shift]}
                          </span>
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: "#e0f2fe", color: "#0f7490" }}>{n.category}</span>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-xs" style={{ fontFamily: "var(--font-mono)", color: "#94a3b8" }}>{n.time}</p>
                          <p className="text-xs" style={{ color: "#64748b" }}>{n.nurse}</p>
                        </div>
                      </div>
                      <p className="text-sm" style={{ color: "#334155" }}>{n.note}</p>
                      {n.followUp && (
                        <div className="mt-2 p-2 rounded-lg" style={{ background: "#f8fafc" }}>
                          <p className="text-xs font-semibold mb-0.5" style={{ color: "#64748b" }}>Tindak Lanjut:</p>
                          <p className="text-xs" style={{ color: "#475569" }}>{n.followUp}</p>
                        </div>
                      )}
                    </div>
                  )) : (
                    <div className="rounded-xl p-8 text-center shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                      <p className="text-sm" style={{ color: "#94a3b8" }}>Belum ada catatan untuk pasien ini</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ════ PEMBERIAN OBAT ════ */}
          {view === "obat" && (
            <div className="p-6 space-y-5">
              <div>
                <h1 className="text-xl font-bold" style={{ color: "#1e293b" }}>Pemberian Obat</h1>
                <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>Konfirmasi pemberian setiap obat sesuai resep dokter</p>
              </div>

              {/* Patient picker */}
              <div className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                <p className="text-xs font-semibold mb-3" style={{ color: "#334155" }}>Pilih Pasien</p>
                <PatientPicker value={medPatientId} onChange={setMedPatientId} />
              </div>

              {/* Medication cards */}
              <div className="space-y-3">
                {patientMeds.length > 0 ? patientMeds.map((m) => (
                  <div key={m.id} className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold" style={{ color: "#1e293b" }}>{m.drug}</p>
                          <span className="text-xs px-1.5 py-0.5 rounded font-mono font-medium" style={{ background: "#e0f2fe", color: "#0f7490" }}>{m.dose}</span>
                          <span className="text-xs px-1.5 py-0.5 rounded font-medium" style={{ background: "#f1f5f9", color: "#475569" }}>{m.route}</span>
                        </div>
                        <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>{m.frequency} · Diresepkan oleh {m.prescribedBy}</p>
                      </div>
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: m.status.every((s) => s === "diberikan") ? "#dcfce7" : "#fef9c3", color: m.status.every((s) => s === "diberikan") ? "#16a34a" : "#d97706" }}>
                        {m.status.filter((s) => s === "diberikan").length}/{m.status.length} terpenuhi
                      </span>
                    </div>
                    <div className="flex gap-3 flex-wrap">
                      {m.times.map((t, idx) => {
                        const ms = MED_STYLE[m.status[idx]];
                        return (
                          <button key={idx} onClick={() => toggleMed(m.id, idx)}
                            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border-2 font-semibold text-sm transition-all hover:shadow-sm"
                            style={{ background: ms.bg, borderColor: m.status[idx] === "diberikan" ? "#86efac" : "#e2e8f0", color: ms.color }}>
                            <span style={{ fontFamily: "var(--font-mono)", fontSize: "11px" }}>{t}</span>
                            <span className="text-xs">{ms.label}</span>
                          </button>
                        );
                      })}
                    </div>
                    {m.status.some((s) => s === "belum") && (
                      <p className="mt-2 text-xs" style={{ color: "#d97706" }}>
                        ⚠ {m.status.filter((s) => s === "belum").length} dosis belum dikonfirmasi — klik tombol waktu untuk update
                      </p>
                    )}
                  </div>
                )) : (
                  <div className="rounded-xl p-8 text-center shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                    <p className="text-sm" style={{ color: "#94a3b8" }}>Tidak ada resep obat aktif untuk pasien ini</p>
                  </div>
                )}
              </div>

              {/* Legend */}
              <div className="flex gap-4 flex-wrap">
                {(Object.entries(MED_STYLE) as [MedStatus, typeof MED_STYLE[MedStatus]][]).map(([k, s]) => (
                  <span key={k} className="flex items-center gap-1.5 text-xs">
                    <span className="w-3 h-3 rounded-sm" style={{ background: s.bg, border: `1px solid ${s.color}` }} />
                    <span style={{ color: "#64748b" }}>{s.label} = {k}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* ════ OBSERVASI ════ */}
          {view === "observasi" && (
            <div className="p-6 space-y-5">
              <div>
                <h1 className="text-xl font-bold" style={{ color: "#1e293b" }}>Observasi Pasien</h1>
                <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>Formulir observasi komprehensif per shift keperawatan</p>
              </div>

              {/* Patient picker */}
              <div className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                <p className="text-xs font-semibold mb-3" style={{ color: "#334155" }}>Pilih Pasien</p>
                <PatientPicker value={obsPatientId} onChange={setObsPatientId} />
              </div>

              <div className="grid grid-cols-5 gap-5">
                {/* Form */}
                <div className="col-span-2 rounded-xl p-5 shadow-sm space-y-4" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                  <h2 className="text-sm font-semibold" style={{ color: "#1e293b" }}>Form Observasi Shift</h2>

                  <div>
                    <label className="text-xs font-semibold block mb-1.5" style={{ color: "#334155" }}>Shift</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(["pagi", "siang", "malam"] as ObsShift[]).map((s) => (
                        <button key={s} onClick={() => setObsForm((f) => ({ ...f, shift: s }))}
                          className="py-2 rounded-lg text-xs font-semibold border-2 capitalize"
                          style={{ background: obsForm.shift === s ? "#e0f2fe" : "#f8fafc", color: obsForm.shift === s ? "#0f7490" : "#64748b", borderColor: obsForm.shift === s ? "#0f7490" : "#e2e8f0" }}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  {([
                    { key: "generalCondition", label: "Kondisi Umum *", placeholder: "Mis. Lemah, composmentis, tampak sesak" },
                    { key: "consciousness",    label: "Kesadaran",       placeholder: "Mis. Composmentis, GCS 15" },
                    { key: "diet",             label: "Nutrisi & Diit", placeholder: "Mis. Habis 3/4 porsi, diit lunak" },
                    { key: "elimination",      label: "Eliminasi",       placeholder: "Mis. BAK 400 mL/6 jam, BAB 1x" },
                    { key: "mobility",         label: "Mobilisasi",      placeholder: "Mis. Bed rest dengan bantuan" },
                    { key: "pain",             label: "Nyeri",           placeholder: "Mis. Skala 2/10, nyeri perut kanan" },
                  ] as const).map((f) => (
                    <div key={f.key}>
                      <label className="text-xs font-semibold block mb-1" style={{ color: "#334155" }}>{f.label}</label>
                      <input className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none"
                        style={{ borderColor: obsErrors[f.key] ? "#dc2626" : "#e2e8f0", color: "#334155" }}
                        placeholder={f.placeholder}
                        value={obsForm[f.key as keyof typeof obsForm]}
                        onChange={(e) => { setObsForm((v) => ({ ...v, [f.key]: e.target.value })); setObsErrors((er) => ({ ...er, [f.key]: "" })); }} />
                      {obsErrors[f.key] && <p className="text-xs mt-0.5" style={{ color: "#dc2626" }}>⚠ {obsErrors[f.key]}</p>}
                    </div>
                  ))}

                  <div>
                    <label className="text-xs font-semibold block mb-1" style={{ color: "#334155" }}>Catatan Tambahan Shift</label>
                    <textarea rows={3} className="w-full border rounded-lg px-3 py-2.5 text-sm outline-none resize-none"
                      style={{ borderColor: "#e2e8f0", color: "#334155" }}
                      placeholder="Hal penting lain yang perlu dilaporkan..."
                      value={obsForm.notes} onChange={(e) => setObsForm((v) => ({ ...v, notes: e.target.value }))} />
                  </div>

                  <button onClick={submitObs} className="w-full py-2.5 rounded-lg text-sm font-semibold text-white"
                    style={{ background: "#0f7490" }}>
                    👁 Simpan Observasi Shift
                  </button>
                </div>

                {/* Obs history */}
                <div className="col-span-3 space-y-3">
                  {patientObs.length > 0 ? patientObs.map((o) => (
                    <div key={o.id} className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium text-white capitalize"
                            style={{ background: o.shift === "pagi" ? "#0f7490" : o.shift === "siang" ? "#d97706" : "#1e293b" }}>
                            {SHIFT_LABEL[o.shift]}
                          </span>
                          <span className="text-xs" style={{ color: "#94a3b8" }}>{o.date}</span>
                        </div>
                        <p className="text-xs" style={{ color: "#64748b" }}>{o.nurse}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { label: "Kondisi Umum", val: o.generalCondition, icon: "🧍" },
                          { label: "Kesadaran",    val: o.consciousness,    icon: "🧠" },
                          { label: "Nutrisi/Diit", val: o.diet,             icon: "🍱" },
                          { label: "Eliminasi",    val: o.elimination,      icon: "💧" },
                          { label: "Mobilisasi",   val: o.mobility,         icon: "🚶" },
                          { label: "Nyeri",        val: o.pain,             icon: "😣" },
                        ].filter((r) => r.val).map((r) => (
                          <div key={r.label} className="p-2 rounded-lg" style={{ background: "#f8fafc" }}>
                            <p className="text-xs font-semibold mb-0.5" style={{ color: "#64748b" }}>{r.icon} {r.label}</p>
                            <p className="text-xs" style={{ color: "#334155" }}>{r.val}</p>
                          </div>
                        ))}
                      </div>
                      {o.notes && (
                        <p className="mt-3 text-xs p-2 rounded-lg" style={{ background: "#fef9c3", color: "#d97706" }}>📝 {o.notes}</p>
                      )}
                    </div>
                  )) : (
                    <div className="rounded-xl p-8 text-center shadow-sm" style={{ background: "#fff", border: "1px solid #e2e8f0" }}>
                      <p className="text-sm" style={{ color: "#94a3b8" }}>Belum ada observasi shift untuk pasien ini</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-5 right-5 px-4 py-3 rounded-lg shadow-lg text-sm font-medium text-white z-50"
          style={{ background: "#0f7490" }}>{toast}</div>
      )}
    </div>
  );
}
