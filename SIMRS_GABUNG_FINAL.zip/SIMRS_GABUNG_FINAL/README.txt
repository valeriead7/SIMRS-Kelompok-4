SIMRS GABUNG FINAL - RS SUKA SEHAT
==================================

STRUKTUR
- Tampilan/login/sidebar utama mengikuti desain Claudia.
- Fungsi asli tiap anggota disimpan di folder modules/ masing-masing.
- Menu utama memakai RBAC: menu yang tidak relevan dengan role otomatis disembunyikan.
- Modul dibuka di area kerja yang sama agar tidak merusak JavaScript/CSS asli masing-masing proyek.

CARA MENJALANKAN (XAMPP)
1. Ekstrak folder SIMRS_GABUNG_FINAL ke C:\xampp\htdocs\
2. Start Apache.
3. Buka http://localhost/SIMRS_GABUNG_FINAL/
4. MySQL tidak diperlukan untuk demo utama.

AKUN PORTAL
admin / admin123
petugas / petugas123
radiolog / radiolog123
dokter / simrs123
perawat / simrs123
gudang / simrs123
farmasi / 123456
laboran / 123456
kasir / simrs123

CATATAN PENTING SHARON
Folder modules/sharon adalah source React/Vite asli dan tetap disimpan utuh.
index.html milik Sharon memerlukan proses build/dev Vite agar seluruh fungsi React dapat dijalankan.
Source tidak diubah agar fungsi asli tidak rusak. Jika ingin menjalankan modul Sharon standalone:
- buka terminal di modules/sharon
- npm install
- npm run dev

Modul Claudia, Valerie, Max, dan Mikael dapat dibuka langsung dari portal melalui Apache.


REVISI SSO:
- Login cukup satu kali di login.php.
- Setelah login, portal langsung membuka modul sesuai pekerjaan.
- Menu pekerjaan lain tidak ditampilkan.
- Halaman login menyediakan 12 akun demo secara terpisah.

REVISI FUNGSI MODUL
- Placeholder pada modul Farmasi (Stok Obat, Retur Obat, Laporan) telah diganti halaman fungsional/demo interaktif.
- Placeholder Scheduling (Jadwal Dokter, Data Pasien) telah diganti halaman fungsional/demo interaktif.
- Modul asli lain tetap dipertahankan dan dibuka di dalam shell UI utama, sehingga sidebar/header utama tetap satu.
